<!--
  @file views/MediumShelfWeightTable.vue
  @description 中型货架重量计算表配置页面

  功能说明：
  - 中型货架自重参数配置与管理
  - 双层表格结构：汇总表 + 明细表
  - 支持编辑模式和预览模式切换
  - 载重参数与配件重量分拆计算
  - 配置数据的 CRUD 操作

  页面布局：
  ┌──────────────────────────────────────────────────────────────┐
  │  MediumShelfWeightTable (中型货架重量表)                     │
  │                                                              │
  │  Toolbar:                                                    │
  │  标题: 中型货架重量表                                       │
  │  副标题: 当前为编辑/预览模式...                             │
  │  按钮: [编辑] 或 [+新增汇总][新增明细][保存][取消] [刷新]  │
  │                                                              │
  │  Error Alert (如有错误)                                      │
  │  ⚠️ 错误提示信息                                           │
  │                                                              │
  │  ┌────────────────────────────────────────────────────────┐  │
  │  │ 区块1: 中型货架重量表 (汇总表)                         │  │
  │  │ ┌────┬────────┬────────┬──────┬──────┬────────┬──────┐ │  │
  │  │ │序号│ 名称   │ 规格   │ 层数  │ 载重  │ 总自重  │ 配件  │ │  │
  │  │ ├────┼────────┼────────┼──────┼──────┼────────┼──────┤ │  │
  │  │ │ 1  │ A型    │ 2000×500│ 4层  │ 2t   │ 150kg  │ 立柱..│ │  │
  │  │ │ 2  │ B型    │ 2500×600│ 5层  │ 3t   │ 200kg  │ 立柱..│ │  │
  │  │ └────┴────────┴────────┴──────┴──────┴────────┴──────┘ │  │
  │  └────────────────────────────────────────────────────────┘  │
  │                                                              │
  │  ┌────────────────────────────────────────────────────────┐  │
  │  │ 区块2: 层数规格明细表                                   │  │
  │  │ ┌────┬────────┬────────┬──────┬──────┬──────┬────────┐ │  │
  │  │ │序号│ 关联ID  │ 层数   │ 自重  │ 载重  │ 单价   │ 备注  │ │  │
  │  │ ├────┼────────┼────────┼──────┼──────┼──────┼────────┤ │  │
  │  │ │ 1  │ #1     │ 4层    │ 120kg│ 500kg│ ¥80   │ 标准  │ │  │
  │  │ └────┴────────┴────────┴──────┴──────┴──────┴────────┘ │  │
  │  └────────────────────────────────────────────────────────┘  │
  └──────────────────────────────────────────────────────────────┘

  双表结构说明：
  ┌─────────────────────────────────────────────────────────────┐
  │  SummaryRow (汇总表行) - 中型货架整体参数                    │
  ├─────────────────────────────────────────────────────────────┤
  │  index: number         - 序号                                │
  │  name: string          - 货架名称/型号                       │
  │  spec: string          - 外形规格                            │
  │  layers: number/string - 层数                                │
  │  load: number/string   - 额定载重                            │
  │  totalWeight: number   - 总自重                              │
  │  accessoryWeights: Object - 配件重量分拆                    │
  │  ├── pillarWeight: number  - 立柱片重量                     │
  │  ├── beamWeight: number    - 横梁重量                       │
  │  ├── shelfWeight: number   - 层板重量                       │
  │  └── otherWeight: number   - 其他配件重量                   │
  └─────────────────────────────────────────────────────────────┘

  ┌─────────────────────────────────────────────────────────────┐
  │  DetailRow (明细表行) - 各层数的具体规格                    │
  ├─────────────────────────────────────────────────────────────┤
  │  index: number         - 序号                                │
  │  summaryId: number     - 关联的汇总表 ID                    │
  │  layers: number/string - 具体层数                            │
  │  weight: number        - 该层数的自重                        │
  │  loadCapacity: number  │  该层数的载重能力                   │
  │  unitPrice: number     - 单价                                │
  │  remark: string        - 备注说明                            │
  └─────────────────────────────────────────────────────────────┘

  模式切换：
  - 预览模式（默认）：只读展示，从服务端加载最新配置
  - 编辑模式：可修改、添加、删除数据，需手动保存

  权限控制：
  - admin/user: 可进入编辑模式，执行 CRUD 操作
  - guest: 仅预览模式，无编辑按钮

  API 调用：
  - GET /api/medium-shelf-weight → 获取当前配置
  - PUT /api/medium-shelf-weight → 保存更新后的配置

  使用场景：
  - 工程师配置标准货架的自重参数
  - 报价系统根据此表自动计算成本
  - 不同层数组合的价格差异分析
-->

<template>

  <!-- * @module views/MediumShelfWeightTable
 * @description 中型货架重量计算表页面
 * 
 * 功能：
 * - 中型货架自重计算
 * - 载重参数配置
 * - 重量与报价关联计算 -->



  <div class="medium-weight-page">
    <!-- 独立应用卡片外壳，去除圆角增强后台感 -->
    <el-card class="page-card" shadow="never" v-loading="loading">

      <!-- 顶部工具栏：包含标题、副标题提示和主要的业务按钮组合 -->
      <div class="toolbar">
        <div>
          <div class="page-title">中型货架重量表</div>
          <div class="page-subtitle">
            <!-- 根据当前的编辑状态显示不同的引导语 -->
            {{ editMode ? '当前为编辑模式，可动态修改、添加或删除层级与结构数据' : '当前为实时预览模式，系统将自动从服务端同步配置' }}
          </div>
        </div>

        <!-- 增删改查操作区 -->
        <div class="toolbar-actions">
          <template v-if="!isGuest">
            <el-button v-if="!editMode" type="primary" :icon="Edit" @click="startEdit">
              编辑
            </el-button>

            <template v-else>
              <el-button :icon="Plus" @click="addSummaryRow">新增中型货架重量表</el-button>
              <el-button :icon="Plus" @click="addDetailRow">新增层数规格明细</el-button>
              <el-button :loading="saving" type="success" @click="saveData">保存</el-button>
              <el-button @click="cancelEdit">取消</el-button>
            </template>
          </template>

          <el-button :icon="Refresh" @click="loadData" :loading="loading">刷新</el-button>
        </div>
      </div>

      <!-- 全局级别的错误展示横幅，用于拦截严重的数据解析异常 -->
      <el-alert v-if="errorMsg" class="mb-16" type="error" :title="errorMsg" :closable="false" show-icon />

      <!-- 当存在可显示的数据时，渲染两个数据表格区块；否则显示空状态 -->
      <template v-if="summaryRows?.length || detailRows?.length">
        <!-- ================= 区块 1: 全局汇总表 ================= -->
        <el-card shadow="never" class="section-card">
          <template #header>
            <div class="section-title">中型货架重量表</div>
          </template>

          <el-table :data="displaySummaryRows" border stripe class="table smart-table"
            :header-cell-style="TABLE_HEADER_STYLE">
            <el-table-column prop="index" label="序号" width="70" align="center" />

            <el-table-column label="名称" min-width="120" align="center">
              <template #default="{ row }">
                <el-input v-if="editMode" v-model="row.name" size="small" placeholder="名称" />
                <span v-else class="config-text">
                  {{ formatConfigText(row.name) }}
                </span>
              </template>
            </el-table-column>

            <el-table-column label="规格" min-width="120" align="center">
              <template #default="{ row }">
                <el-input v-if="editMode" v-model="row.spec" size="small" placeholder="规格" />
                <span v-else>{{ row.spec }}</span>
              </template>
            </el-table-column>

            <el-table-column label="层数" width="90" align="center">
              <template #default="{ row }">
                <el-input v-if="editMode" v-model="row.layers" size="small" placeholder="层数" />
                <span v-else>{{ row.layers }}</span>
              </template>
            </el-table-column>

            <el-table-column label="载重" width="110" align="center">
              <template #default="{ row }">
                <el-input v-if="editMode" v-model="row.load" size="small" placeholder="载重" />
                <span v-else>{{ row.load }}</span>
              </template>
            </el-table-column>

            <el-table-column label="总自重" width="110" align="center">
              <template #default="{ row }">
                <el-input v-if="editMode" v-model="row.totalWeight" size="small" placeholder="总自重" />
                <span v-else>{{ row.totalWeight }}</span>
              </template>
            </el-table-column>

            <el-table-column label="配件分拆重量">
              <el-table-column label="立柱片" width="110" align="center">
                <template #default="{ row }">
                  <el-input v-if="editMode" v-model="row.uprightWeight" size="small" placeholder="立柱片" />
                  <span v-else>{{ row.uprightWeight }}</span>
                </template>
              </el-table-column>

              <el-table-column label="横梁" width="110" align="center">
                <template #default="{ row }">
                  <el-input v-if="editMode" v-model="row.beamWeight" size="small" placeholder="横梁" />
                  <span v-else>{{ row.beamWeight }}</span>
                </template>
              </el-table-column>

              <el-table-column label="层板" width="110" align="center">
                <template #default="{ row }">
                  <el-input v-if="editMode" v-model="row.shelfWeight" size="small" placeholder="层板" />
                  <span v-else>{{ row.shelfWeight }}</span>
                </template>
              </el-table-column>
            </el-table-column>

            <el-table-column v-if="editMode" label="操作" width="90" align="center" fixed="right">
              <template #default="{ $index }">
                <el-button type="danger" link @click="removeSummaryRow($index)">
                  删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>

        <!-- ================= 区块 2: 层数规格明细表（带单元格合并功能） ================= -->
        <el-card shadow="never" class="section-card">
          <template #header>
            <div class="section-title">层数规格明细</div>
          </template>

          <el-table :data="displayDetailRows" border stripe class="table smart-table"
            :header-cell-style="TABLE_HEADER_STYLE" :span-method="editMode ? undefined : detailSpanMethod"
            row-key="index">
            <el-table-column prop="index" label="序号" width="70" align="center" />

            <el-table-column label="层数" width="90" align="center">
              <template #default="{ row }">
                <el-input v-if="editMode" v-model="row.layerGroup" size="small" placeholder="层数" />
                <span v-else>{{ row.layerGroup }}</span>
              </template>
            </el-table-column>

            <el-table-column label="规格（L*W*H）" min-width="170" align="center">
              <template #default="{ row }">
                <el-input v-if="editMode" v-model="row.spec" size="small" placeholder="规格" />
                <span v-else>{{ row.spec }}</span>
              </template>
            </el-table-column>

            <el-table-column label="载重（kg/层）" width="120" align="center">
              <template #default="{ row }">
                <el-input v-if="editMode" v-model="row.loadPerLayer" size="small" placeholder="载重" />
                <span v-else>{{ row.loadPerLayer }}</span>
              </template>
            </el-table-column>
            <el-table-column label="报价" min-width="200" align="center">
              <template #default="{ row }">
                <div class="wrap-text">
                  <el-input v-if="editMode" v-model="row.quote" type="textarea" :rows="2" resize="none" />
                  <span v-else>{{ row.quote }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="实际" min-width="200" align="center">
              <template #default="{ row }">
                <div class="wrap-text">
                  <el-input v-if="editMode" v-model="row.actual" type="textarea" :rows="2" resize="none" />
                  <span v-else>{{ row.actual }}</span>
                </div>
              </template>
            </el-table-column>

            <el-table-column v-if="editMode" label="操作" width="90" align="center" fixed="right">
              <template #default="{ $index }">
                <el-button type="danger" link @click="removeDetailRow($index)">
                  删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </template>

      <el-empty v-else description="暂无数据" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { Edit, Plus, Refresh } from '@element-plus/icons-vue'
import { usePermissions } from '@/composables/usePermissions'
import { useMediumShelfWeight } from '@/composables/useMediumShelfWeight'
import { TABLE_HEADER_STYLE } from '@/constants/table'

const { isGuest } = usePermissions()

const {
  loading,
  saving,
  errorMsg,
  editMode,
  summaryRows,
  detailRows,
  displaySummaryRows,
  displayDetailRows,
  formatConfigText,
  loadData,
  startEdit,
  cancelEdit,
  addSummaryRow,
  addDetailRow,
  removeSummaryRow,
  removeDetailRow,
  saveData
} = useMediumShelfWeight()

/**
 * 只对连续相同值的单元格进行合并。
 * 这样“报价 / 实际”相同且连续的行会自动合并。
 */
const buildSpanMap = (rows: Record<string, unknown>[], field: string) => {
  if (!Array.isArray(rows) || !rows.length) return {}
  const map: Record<number, number> = {}
  let i = 0

  while (i < rows.length) {
    const currentValue = rows[i]?.[field]
    let count = 1

    while (i + count < rows.length && rows[i + count]?.[field] === currentValue) {
      count += 1
    }

    map[i] = count
    for (let j = 1; j < count; j += 1) {
      map[i + j] = 0
    }

    i += count
  }

  return map
}

const detailSpanMaps = computed(() => {
  const rows = displayDetailRows.value
  if (!rows || !rows.length) return { layerGroup: {}, loadPerLayer: {}, quote: {}, actual: {} }
  return {
    layerGroup: buildSpanMap(rows, 'layerGroup'),
    loadPerLayer: buildSpanMap(rows, 'loadPerLayer'),
    quote: buildSpanMap(rows, 'quote'),
    actual: buildSpanMap(rows, 'actual')
  }
})

const detailSpanMethod = ({ rowIndex, columnIndex }: { rowIndex: number; columnIndex: number }) => {
  const spanMapList: Record<number, Record<number, number>> = {
    1: detailSpanMaps.value.layerGroup,
    3: detailSpanMaps.value.loadPerLayer,
    4: detailSpanMaps.value.quote,
    5: detailSpanMaps.value.actual
  }

  const spanMap = spanMapList[columnIndex]
  if (!spanMap) return [1, 1]

  const span = spanMap[rowIndex]
  if (span === 0) return [0, 0]
  if (span > 1) return [span, 1]
  return [1, 1]
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.medium-weight-page {
  min-height: 100%;
}

.page-card {
  border-radius: 12px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.04);
}

.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.toolbar-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.page-title {
  font-size: 18px;
  font-weight: bold;
  color: #303133;
}

.page-subtitle {
  margin-top: 4px;
  font-size: 13px;
  color: #909399;
}

.section-card {
  margin-top: 16px;
  border-radius: 4px;
}

.section-title {
  font-size: 15px;
  font-weight: bold;
  color: #1e293b;
  border-left: 4px solid #6366f1;
  /* 使用统一的靛蓝色调 */
  padding-left: 10px;
  line-height: 1;
}

.config-text {
  white-space: pre-line;
  /* 让 \n 生效 */
  line-height: 1.6;
  word-break: break-word;
}

.table {
  width: 100%;
}

.mb-16 {
  margin-bottom: 16px;
}

@media (max-width: 768px) {
  .toolbar {
    margin-bottom: 12px;
    gap: 10px;
  }

  .page-title {
    font-size: 16px;
  }

  .page-subtitle {
    font-size: 12px;
    line-height: 1.5;
  }

  .toolbar-actions {
    width: 100%;
  }

  .toolbar-actions :deep(.el-button) {
    margin-left: 0;
  }

  .section-card {
    margin-top: 12px;
  }
}
</style>