<template>
  <div class="quotation-verify-page">
    <div class="editor-toolbar">
      <div class="toolbar-left">
        <el-tag type="success" effect="plain">Word 编辑模式</el-tag>
        <span class="toolbar-hint">纸张里的内容都可以直接编辑，导出时会生成 .docx</span>
      </div>
      <div class="toolbar-actions">
        <el-button size="small" :icon="Document" @click="fillDemo">填充模板示例</el-button>
        <el-button size="small" :icon="RefreshLeft" @click="resetForm">清空重填</el-button>
        <el-button size="small" :icon="Plus" @click="addRow">新增明细行</el-button>
        <el-button type="primary" size="small" :icon="CircleCheck" @click="runValidation">开始验证</el-button>
        <el-button size="small" :icon="Download" :loading="exporting" @click="downloadWord">导出 Word</el-button>
      </div>
    </div>

    <div class="doc-stack">
      <section class="doc-page">
        <header class="doc-header">
          <img src="/logo.png" alt="logo" class="doc-logo" />
          <div class="doc-header-title">
            <textarea v-model="form.companyEn" class="doc-title-edit title-en-edit" rows="1"></textarea>
            <textarea v-model="form.companyCn" class="doc-title-edit title-cn-edit" rows="1"></textarea>
            <textarea v-model="form.quoteCn" class="doc-title-edit quote-cn-edit" rows="1"></textarea>
            <textarea v-model="form.quoteEn" class="doc-title-edit quote-en-edit" rows="1"></textarea>
          </div>
        </header>

        <div class="mini-table">
          <div v-for="(row, index) in headerRows" :key="index" class="mini-row">
            <div class="mini-cell">
              <span>{{ row.leftLabel }}</span>
              <input v-model="form[row.leftKey]" class="word-input inline-input" :placeholder="row.leftPlaceholder" />
            </div>
            <div class="mini-cell">
              <span>{{ row.rightLabel }}</span>
              <input v-model="form[row.rightKey]" class="word-input inline-input" :placeholder="row.rightPlaceholder" />
            </div>
          </div>
        </div>

        <section class="section-block">
          <h2>一、公司简介：</h2>
          <textarea v-for="(paragraph, index) in form.introPage1" :key="`p1-${index}`" v-model="form.introPage1[index]" class="word-textarea body-textarea" rows="3"></textarea>
        </section>

        <footer class="doc-footer">
          <div>{{ form.footerPage1 }}</div>
          <div>{{ form.footerAddress }}</div>
          <div>{{ form.footerTel }}</div>
          <div>{{ form.footerMail }}</div>
          <div>{{ form.footerSite }}</div>
        </footer>
      </section>

      <section class="doc-page">
        <header class="doc-header compact-header">
          <img src="/logo.png" alt="logo" class="doc-logo" />
          <div class="doc-header-title">
            <textarea v-model="form.companyEn" class="doc-title-edit title-en-edit compact-edit" rows="1"></textarea>
            <textarea v-model="form.companyCn" class="doc-title-edit title-cn-edit compact-edit" rows="1"></textarea>
          </div>
        </header>

        <section class="section-block">
          <textarea v-for="(paragraph, index) in form.introPage2" :key="`p2-${index}`" v-model="form.introPage2[index]" class="word-textarea body-textarea" rows="3"></textarea>
        </section>

        <section class="section-block tech-block">
          <h2>二、技术要求：</h2>
          <div class="numbered-list">
            <textarea v-for="(item, index) in form.techRequirements" :key="`tech-${index}`" v-model="form.techRequirements[index]" class="word-textarea list-textarea" rows="2"></textarea>
          </div>
          <textarea v-model="form.techColdSpec" class="word-textarea body-textarea inline-line" rows="2"></textarea>
          <table class="spec-table narrow">
            <thead>
              <tr>
                <th>钢号</th>
                <th>钢材种类</th>
                <th>抗拉、抗压、抗弯</th>
                <th>抗剪</th>
                <th>端面承压</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><input v-model="form.techColdTable.steelNo" class="word-input table-input center" /></td>
                <td><input v-model="form.techColdTable.material" class="word-input table-input center" /></td>
                <td><input v-model="form.techColdTable.tensile" class="word-input table-input center" /></td>
                <td><input v-model="form.techColdTable.shear" class="word-input table-input center" /></td>
                <td><input v-model="form.techColdTable.bearing" class="word-input table-input center" /></td>
              </tr>
            </tbody>
          </table>
          <textarea v-model="form.techWeldSpec" class="word-textarea body-textarea inline-line" rows="2"></textarea>
        </section>

        <footer class="doc-footer">
          <div>{{ form.footerPage2 }}</div>
          <div>{{ form.footerAddress }}</div>
          <div>{{ form.footerTel }}</div>
          <div>{{ form.footerMail }}</div>
          <div>{{ form.footerSite }}</div>
        </footer>
      </section>

      <section class="doc-page">
        <header class="doc-header compact-header">
          <img src="/logo.png" alt="logo" class="doc-logo" />
          <div class="doc-header-title">
            <textarea v-model="form.companyEn" class="doc-title-edit title-en-edit compact-edit" rows="1"></textarea>
            <textarea v-model="form.companyCn" class="doc-title-edit title-cn-edit compact-edit" rows="1"></textarea>
          </div>
        </header>

        <section class="section-block tech-block top-gap-small">
          <table class="spec-table wide-top">
            <thead>
              <tr>
                <th colspan="2">钢材</th>
                <th colspan="2">对接焊接</th>
                <th colspan="2">角焊缝</th>
              </tr>
              <tr>
                <th>钢号</th>
                <th>钢材种类</th>
                <th>抗压</th>
                <th>抗拉</th>
                <th>抗剪</th>
                <th>抗压、抗拉、抗剪</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><input v-model="form.techWeldTable.steelNo" class="word-input table-input center" /></td>
                <td><input v-model="form.techWeldTable.material" class="word-input table-input center" /></td>
                <td><input v-model="form.techWeldTable.pressure" class="word-input table-input center" /></td>
                <td><input v-model="form.techWeldTable.tensile" class="word-input table-input center" /></td>
                <td><input v-model="form.techWeldTable.shear" class="word-input table-input center" /></td>
                <td><input v-model="form.techWeldTable.all" class="word-input table-input center" /></td>
              </tr>
            </tbody>
          </table>
          <textarea v-model="form.techWeldProcess" class="word-textarea body-textarea" rows="2"></textarea>
          <textarea v-model="form.surfaceTreatment" class="word-textarea body-textarea" rows="3"></textarea>
          <textarea v-model="form.processFlow" class="word-textarea body-textarea" rows="2"></textarea>
        </section>

        <section class="section-block">
          <h2>三、货架表面颜色：</h2>
          <input v-model="form.surfaceColor" class="word-input surface-color-input" placeholder="请输入货架表面颜色" />
        </section>

        <section class="section-block">
          <h2>四、报价单明细：</h2>
          <div class="quote-line-editor">
            <input v-model="form.projectTitle" class="word-input line-title-input" placeholder="请输入产品名称" />
            <textarea v-model="form.projectDesc" class="word-textarea line-desc-input" rows="2" placeholder="请输入规格与描述"></textarea>
          </div>

          <table ref="quoteTableRef" class="quote-table">
            <thead>
              <tr>
                <th>名称</th>
                <th>规格（mm）长*宽*高</th>
                <th>数量</th>
                <th>单价（元）</th>
                <th>合计（元）</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td colspan="5" class="merged-row">
                  <span class="merged-prefix">{{ form.projectTitle || '双深位货架' }}：</span>
                  <textarea v-model="form.projectDesc" class="word-textarea merged-textarea" rows="2"></textarea>
                </td>
              </tr>
              <tr v-for="(row, idx) in rows" :key="`row-${idx}`" class="quote-row">
                <td><input v-model="row.name" class="word-input table-input center" placeholder="名称" /></td>
                <td><input v-model="row.spec" class="word-input table-input center" placeholder="规格" /></td>
                <td><input v-model="row.quantity" class="word-input table-input center" placeholder="12套 / 12层" /></td>
                <td><input v-model="row.unitPrice" class="word-input table-input center" placeholder="单价" /></td>
                <td>
                  <div class="table-cell-with-action">
                    <input :value="row.totalPrice" class="word-input table-input center" placeholder="自动计算" readonly />
                    <el-button link type="danger" class="delete-inline-btn" @click="removeRow(idx)">删除</el-button>
                  </div>
                </td>
              </tr>
              <tr>
                <td>合计</td>
                <td></td>
                <td></td>
                <td></td>
                <td class="grand-total-cell">{{ grandTotalDisplay }}</td>
              </tr>
              <tr>
                <td>备注</td>
                <td colspan="4">
                  <textarea v-model="form.remark" class="word-textarea remark-textarea" rows="2" placeholder="备注"></textarea>
                </td>
              </tr>
            </tbody>
          </table>
        </section>

        <footer class="doc-footer">
          <div>{{ form.footerPage3 }}</div>
          <div>{{ form.footerAddress }}</div>
          <div>{{ form.footerTel }}</div>
          <div>{{ form.footerMail }}</div>
          <div>{{ form.footerSite }}</div>
        </footer>
      </section>

      <section class="doc-page">
        <header class="doc-header compact-header">
          <img src="/logo.png" alt="logo" class="doc-logo" />
          <div class="doc-header-title">
            <textarea v-model="form.companyEn" class="doc-title-edit title-en-edit compact-edit" rows="1"></textarea>
            <textarea v-model="form.companyCn" class="doc-title-edit title-cn-edit compact-edit" rows="1"></textarea>
          </div>
        </header>

        <section class="section-block">
          <h2>五、公司案例：</h2>
          <table class="cases-table">
            <thead>
              <tr>
                <th>序号</th>
                <th>客户单位名称</th>
                <th>序号</th>
                <th>客户单位名称</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(row, index) in form.caseRows" :key="`case-${index}`">
                <td><input v-model="row.leftNo" class="word-input table-input center" /></td>
                <td><input v-model="row.leftName" class="word-input table-input" /></td>
                <td><input v-model="row.rightNo" class="word-input table-input center" /></td>
                <td><input v-model="row.rightName" class="word-input table-input" /></td>
              </tr>
            </tbody>
          </table>
        </section>

        <section class="section-block">
          <h2>六、售后服务：</h2>
          <textarea v-for="(paragraph, index) in form.afterSales" :key="`after-${index}`" v-model="form.afterSales[index]" class="word-textarea body-textarea" rows="3"></textarea>
        </section>

        <footer class="doc-footer">
          <div>{{ form.footerPage4 }}</div>
          <div>{{ form.footerAddress }}</div>
          <div>{{ form.footerTel }}</div>
          <div>{{ form.footerMail }}</div>
          <div>{{ form.footerSite }}</div>
        </footer>
      </section>

      <section class="doc-page">
        <header class="doc-header compact-header">
          <img src="/logo.png" alt="logo" class="doc-logo" />
          <div class="doc-header-title">
            <textarea v-model="form.companyEn" class="doc-title-edit title-en-edit compact-edit" rows="1"></textarea>
            <textarea v-model="form.companyCn" class="doc-title-edit title-cn-edit compact-edit" rows="1"></textarea>
          </div>
        </header>

        <section class="section-block after-sales-block">
          <textarea v-for="(paragraph, index) in form.afterSalesMore" :key="`after2-${index}`" v-model="form.afterSalesMore[index]" class="word-textarea body-textarea" rows="3"></textarea>
        </section>

        <footer class="doc-footer">
          <div>{{ form.footerPage5 }}</div>
          <div>{{ form.footerAddress }}</div>
          <div>{{ form.footerTel }}</div>
          <div>{{ form.footerMail }}</div>
          <div>{{ form.footerSite }}</div>
        </footer>
      </section>
    </div>

    <el-card shadow="never" class="result-card">
      <template #header>
        <div class="panel-title">
          <span>验证结果</span>
          <el-tag v-if="report" :type="report.pass ? 'success' : 'warning'" effect="plain">
            {{ report.pass ? '全部通过' : '存在差异' }}
          </el-tag>
        </div>
      </template>

      <el-empty v-if="!report" description="点击“开始验证”后显示比对结果" />

      <template v-else>
        <el-row :gutter="12" class="result-overview">
          <el-col :xs="24" :sm="8">
            <div class="stat-box">
              <span>通过 / 总数</span>
              <strong>{{ report.summary.passed }} / {{ report.summary.total }}</strong>
            </div>
          </el-col>
          <el-col :xs="24" :sm="8">
            <div class="stat-box">
              <span>失败项</span>
              <strong>{{ report.summary.failed }}</strong>
            </div>
          </el-col>
          <el-col :xs="24" :sm="8">
            <div class="stat-box">
              <span>匹配率</span>
              <strong>{{ report.summary.rate }}%</strong>
            </div>
          </el-col>
        </el-row>

        <el-alert v-if="report.issues.length" type="warning" :closable="false" class="issue-alert">
          <template #title>需要修正的内容</template>
          <ul class="issue-list">
            <li v-for="(issue, index) in report.issues" :key="index">{{ issue }}</li>
          </ul>
        </el-alert>

        <el-divider content-position="left">基础信息校验</el-divider>
        <el-table :data="report.baseChecks" border stripe :header-cell-style="headerStyle" class="report-table">
          <el-table-column prop="label" label="字段" width="140" />
          <el-table-column prop="expected" label="模板值" min-width="220" />
          <el-table-column prop="actual" label="当前填写" min-width="220" />
          <el-table-column prop="statusText" label="结果" width="100" align="center" />
          <el-table-column prop="note" label="说明" min-width="220" />
        </el-table>

        <el-divider content-position="left">文案内容校验</el-divider>
        <el-table :data="report.textChecks" border stripe :header-cell-style="headerStyle" class="report-table">
          <el-table-column prop="label" label="字段" width="160" />
          <el-table-column prop="expected" label="模板值" min-width="240" />
          <el-table-column prop="actual" label="当前填写" min-width="240" />
          <el-table-column prop="statusText" label="结果" width="100" align="center" />
          <el-table-column prop="note" label="说明" min-width="220" />
        </el-table>

        <el-divider content-position="left">明细行校验</el-divider>
        <el-table :data="report.itemChecks" border stripe :header-cell-style="headerStyle" class="report-table">
          <el-table-column prop="label" label="行名称" width="180" />
          <el-table-column prop="expectedSummary" label="模板摘要" min-width="250" />
          <el-table-column prop="actualSummary" label="当前摘要" min-width="250" />
          <el-table-column prop="statusText" label="结果" width="100" align="center" />
          <el-table-column prop="note" label="说明" min-width="220" />
        </el-table>
      </template>
    </el-card>
  </div>
</template>

<script setup>
import { computed, nextTick, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { CircleCheck, Document, Download, Plus, RefreshLeft } from '@element-plus/icons-vue'
import { quotationApi } from '@/api/quotation'

const headerStyle = { background: '#f8fafc', color: '#475569', fontWeight: 'bold' }

const defaultData = Object.freeze({
  companyEn: 'COMPANY PROFILE',
  companyCn: '武汉倍力特物流装备有限公司',
  quoteCn: '报价单',
  quoteEn: '(Quotation)',
  leftBuyer: '武汉洞察国际咨询有限公司',
  rightSupplier: '武汉倍力特物流装备有限公司',
  leftDepartment: '',
  rightDepartment: '销售部',
  leftContact: '',
  rightContact: '毕乐',
  leftFax: '',
  rightFax: '',
  leftTel: '',
  rightTel: '19971359977',
  leftDate: '2026-03-27',
  rightDate: '2026-03-27',
  footerPage1: '第 1 页 共 5 页',
  footerPage2: '第 2 页 共 5 页',
  footerPage3: '第 3 页 共 5 页',
  footerPage4: '第 4 页 共 5 页',
  footerPage5: '第 5 页 共 5 页',
  footerAddress: '地址：武汉市蔡甸区桐湖农场香炉山工业园特1号',
  footerTel: '电话（Tel）：027-69340899',
  footerMail: 'mail:bltrack@163.com',
  footerSite: 'Http://www.bltvip.com',
  introPage1: [
    '武汉倍力特物流装备有限公司位于武汉市蔡甸区，大型生产厂家，厂区10000平米，拥有各类仓储产品生产设备，从冷热卷板的纵剪，通过型材轧机，高精度专用货架轧机，数控冲压，焊接到静电粉末自动喷塑流水线等多条生产线，形成一套完整的生产体系。',
    '倍力特货架以其卓越的品质，领先的技术，独特的设计，实用的功能，合理的价格，以各种方式为广大新老客商提供满意的产品与优质的服务。产品广泛应用于机电，航空，电子，机械，汽车，邮电，铁路，码头，食品，纺织，石化，文教，金融等行业。'
  ],
  introPage2: [
    '武汉倍力特物流装备有限公司追求每个工程的最优化，最好的质量和完善的售后服务。公司已先后为国内外知名企业完成了大型仓库，物流配送中心工程的建设。深得众多跨国集团在华企业和国内企业的一致好评。并已成为众多大型跨国公司物流设备定点优先采购企业。',
    '倍力特货架人珍视已取得的成就，不断完善管理制度，超越自我，开拓设置前沿性服务内容，根据客户不同需要设计，制作各种特殊规格货架，柜台，为各类型商场提供整体布局，货架配置，商品陈列等技术咨询服务。',
    '倍力特货架以配送作为现代物流的主体功能，日益受到广大厂商的重视，现代物流的核心是使用先进技术，设备与管理为销售提供准确，先进，高效的服务。倍力特公司以追求无止境的专业精神，完善周到的售前服务体系，积极努力为客户创造设计更理想的仓储系列产品。',
    '武汉倍力特物流装备有限公司服务宗旨：创一流诚信品牌，没有最好，只有更好！',
    '倍力特货架以一流的品质求生存，以一流的服务求发展，为您设计制造一流的商业环境。'
  ],
  techRequirements: [
    '1.严格按ISO9001质量体系运行，使产品质量得到充分地保障。',
    '2.货架刚性及强度均符合国家机械部待业标准GB/T5323-91.',
    '3.货架材质及强度指标：所有货架的构件均采用武钢原材料轧制、加工的型材制作。其强度指标如下：立柱Q235 横梁Q235',
    '4.货架冷轧型材的强度指标（N/mm2）',
    '5.货架焊缝的强度指标（N/mm2）',
    '6.表面处理：环氧树脂粉喷塑，具有附着力强，耐磨，外形美观的特点。涂层厚度可达60-80微米，固化温度180℃。所有金属经严格酸洗、碳化处理，表面硬度经2H铅笔测试无划痕，达到国家标准GB6739-86标准,保证表面质量。',
    '7.工艺流程：黑坯→除油→化学除锈→清洗→磷化→清洗→喷塑→流平→固化→成品→包装→入库。'
  ],
  techColdSpec: '货架冷轧型材的强度指标（N/mm2）',
  techColdTable: {
    steelNo: 'Q235',
    material: '冷弯型钢',
    tensile: '205',
    shear: '120',
    bearing: '310'
  },
  techWeldSpec: '焊接工艺:焊缝采用二氧化碳气体（CO2）保护焊。',
  techWeldTable: {
    steelNo: 'Q235',
    material: '冷弯型钢',
    pressure: '205',
    tensile: '175',
    shear: '120',
    all: '140'
  },
  techWeldProcess: '焊接工艺:焊缝采用二氧化碳气体（CO2）保护焊。',
  surfaceTreatment: '表面处理：环氧树脂粉喷塑，具有附着力强，耐磨，外形美观的特点。涂层厚度可达60-80微米，固化温度180℃。所有金属经严格酸洗、碳化处理，表面硬度经2H铅笔测试无划痕，达到国家标准GB6739-86标准,保证表面质量。',
  processFlow: '工艺流程：黑坯→除油→化学除锈→清洗→磷化→清洗→喷塑→流平→固化→成品→包装→入库。',
  surfaceColor: '',
  projectTitle: '双深位货架',
  projectDesc: 'L2700（内）*W1050*H10050mm*6层横梁*6层放货；载重：3000kg/层；数量：14主架126副架',
  remark: '报价含税费（13%增值税），含运费；不含安装费。',
  items: [
    { name: '立柱片', spec: 'H10050*W1050mm（120*90*2.5mm）', quantity: '154片', unitPrice: '', totalPrice: '' },
    { name: '横梁', spec: 'L2700mm（160*50*1.5mm双C抱焊梁）', quantity: '1680根', unitPrice: '', totalPrice: '' },
    { name: '工字跨梁', spec: '', quantity: '1680根', unitPrice: '', totalPrice: '' },
    { name: '连接杆', spec: 'L200mm（30*50*1.5mm矩管）', quantity: '550根', unitPrice: '', totalPrice: '' },
    { name: '防撞护脚', spec: 'H300mm（3.0mm）', quantity: '154个', unitPrice: '', totalPrice: '' },
    { name: '防撞护栏', spec: 'L1000*H300mm（Φ76*2.5mm ）', quantity: '28个', unitPrice: '', totalPrice: '' },
    { name: '运费', spec: '深圳', quantity: '1项', unitPrice: '', totalPrice: '' }
  ],
  caseRows: [
    { leftNo: '1', leftName: '武汉新宁捷通物流有限公司', rightNo: '13', rightName: '越海全球物流（武汉）有限公司' },
    { leftNo: '2', leftName: '菜鸟集团', rightNo: '14', rightName: '黄石三丰集团' },
    { leftNo: '3', leftName: '湖南雨润供应链管理有限公司', rightNo: '15', rightName: '顺丰速运（集团）有限公司' },
    { leftNo: '4', leftName: '康明斯（中国）投资有限公司', rightNo: '16', rightName: '湖南水羊物流有限公司' },
    { leftNo: '5', leftName: '唐山百川智能机械有限公司', rightNo: '17', rightName: '国药控股湖北有限公司' },
    { leftNo: '6', leftName: '内蒙古包钢钢联股份有限公司', rightNo: '18', rightName: '武汉恒基达鑫国际化工仓储有限公司' },
    { leftNo: '7', leftName: '华润雪花啤酒（武汉）有限公司', rightNo: '19', rightName: '湖北祥云（集团）化工股份有限公司' },
    { leftNo: '8', leftName: '顺丰速运（集团）有限公司', rightNo: '20', rightName: '长江文艺出版社有限公司' },
    { leftNo: '9', leftName: '京东世纪贸易有限公司', rightNo: '21', rightName: '大连万达集团股份有限公司' },
    { leftNo: '10', leftName: '云南力帆骏马车辆有限公司', rightNo: '22', rightName: '宜家家具' },
    { leftNo: '11', leftName: '凌致时装（天津）有限公司', rightNo: '23', rightName: '贵州吉利新能源汽车有限公司' },
    { leftNo: '12', leftName: '中粮集团', rightNo: '24', rightName: '大唐国际发电股份有限公司' }
  ],
  afterSales: [
    '我公司保证所提供的产品为全新的、未使用过的、质量优越的与合同规定的质量、规格和性能要求完全一致，并完全符合国家、行业有关标准。',
    '我公司保证产品在正确安装、正常使用和保养条件下，在其使用寿命期内具有良好的性能。',
    '产品最终交付验收后2年的保质期内，如发生事故、变形、开裂、蜕皮、确因我方设计、制造、安装等存在质量问题，由我方负责维修。确因采购方或使用单位使用不当造成质量问题，我方负责修理。'
  ],
  afterSalesMore: [
    '我公司在接到采购方或使用单位通知后，保证在承诺的维修响应时间内到达指定现场进行维修或更换有缺陷的货物和部件。',
    '我公司可无偿为采购方或使用单位提供安装小视频及安装技术支持，采购方或使用单位可自行安装。'
  ]
})

const headerRows = [
  { leftLabel: '采购方（Purchaser）：', leftKey: 'leftBuyer', leftPlaceholder: '请输入采购方', rightLabel: '供货方 (Supplier)：', rightKey: 'rightSupplier', rightPlaceholder: '请输入供货方' },
  { leftLabel: '部门（Department）：', leftKey: 'leftDepartment', leftPlaceholder: '请输入部门', rightLabel: '部门（Department）：', rightKey: 'rightDepartment', rightPlaceholder: '请输入部门' },
  { leftLabel: '联系人：（Contacts）：', leftKey: 'leftContact', leftPlaceholder: '请输入联系人', rightLabel: '联系人：（Contacts）：', rightKey: 'rightContact', rightPlaceholder: '请输入联系人' },
  { leftLabel: '传真（Fax）：', leftKey: 'leftFax', leftPlaceholder: '可留空', rightLabel: '传真（Fax）：', rightKey: 'rightFax', rightPlaceholder: '可留空' },
  { leftLabel: '电话（Tel）：', leftKey: 'leftTel', leftPlaceholder: '可留空', rightLabel: '电话（Tel）：', rightKey: 'rightTel', rightPlaceholder: '请输入电话' },
  { leftLabel: '日期（Date）：', leftKey: 'leftDate', leftPlaceholder: 'YYYY-MM-DD', rightLabel: '日期（Date）：', rightKey: 'rightDate', rightPlaceholder: 'YYYY-MM-DD' }
]

const createRow = () => ({ name: '', spec: '', quantity: '', unitPrice: '', totalPrice: '' })
const rows = ref(defaultData.items.map((item) => ({ ...item })))
const report = ref(null)
const exporting = ref(false)
const quoteTableRef = ref(null)

const form = reactive(JSON.parse(JSON.stringify(defaultData)))

const grandTotalDisplay = computed(() => formatAmount(rows.value.reduce((sum, row) => sum + parseMoney(row.totalPrice), 0)))

function normalizeText(value) {
  return String(value ?? '')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, '')
    .replace(/[（]/g, '(')
    .replace(/[）]/g, ')')
    .replace(/[：]/g, ':')
    .replace(/[，]/g, ',')
    .replace(/[×]/g, '*')
    .trim()
}

function formatCnDate(value) {
  const text = String(value ?? '').trim()
  const match = text.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/)
  if (match) {
    const [, year, month, day] = match
    return `${year}年${String(month).padStart(2, '0')}月${String(day).padStart(2, '0')}日`
  }
  return text || '—'
}

function parseMoney(value) {
  const num = Number(String(value ?? '').replace(/,/g, '').replace(/[元￥\s]/g, '').trim())
  return Number.isFinite(num) ? num : 0
}

function parseQuantityNumber(value) {
  const text = String(value ?? '').replace(/,/g, '')
  const match = text.match(/-?\d+(?:\.\d+)?/)
  if (!match) return null
  const num = Number(match[0])
  return Number.isFinite(num) ? num : null
}

function formatAmount(num) {
  const value = Number(num || 0)
  if (!Number.isFinite(value)) return ''
  const fixed = value.toFixed(2)
  return fixed.replace(/\.00$/, '').replace(/(\.\d)0$/, '$1')
}

function recalcRows() {
  rows.value.forEach((row) => {
    const qty = parseQuantityNumber(row.quantity)
    const price = parseMoney(row.unitPrice)
    if (qty === null || !price) {
      row.totalPrice = ''
      return
    }
    row.totalPrice = formatAmount(qty * price)
  })
}

watch(rows, recalcRows, { deep: true, immediate: true })

const displayDate = computed(() => formatCnDate(form.rightDate))

const cloneRows = (items = []) => items.map(item => ({
  name: item.name || '',
  spec: item.spec || '',
  quantity: item.quantity || '',
  unitPrice: item.unitPrice || '',
  totalPrice: item.totalPrice || ''
}))

const addRow = async () => {
  rows.value.push(createRow())
  await nextTick()
  const elements = document.querySelectorAll('.quote-row')
  const last = elements?.[elements.length - 1]
  last?.scrollIntoView({ behavior: 'smooth', block: 'center' })
}

const removeRow = (index) => {
  rows.value.splice(index, 1)
  if (!rows.value.length) rows.value.push(createRow())
}

const resetForm = () => {
  Object.assign(form, JSON.parse(JSON.stringify(defaultData)))
  rows.value = defaultData.items.map(item => ({ ...item }))
  report.value = null
}

const fillDemo = () => {
  Object.assign(form, JSON.parse(JSON.stringify(defaultData)))
  rows.value = cloneRows(defaultData.items)
  ElMessage.success('已填充模板示例')
}

const extractErrorMessage = async (error) => {
  const data = error?.response?.data
  if (data instanceof Blob) {
    try {
      const text = await data.text()
      const json = JSON.parse(text)
      return json?.message || text || 'Word 导出失败'
    } catch {
      try {
        return await data.text()
      } catch {
        return 'Word 导出失败'
      }
    }
  }
  return error?.response?.data?.message || error?.message || 'Word 导出失败'
}

const downloadWord = async () => {
  if (exporting.value) return
  exporting.value = true
  try {
    const payload = buildExportPayload()
    const blob = await quotationApi.exportVerifyDocx(payload)
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = '货架报价单.docx'
    link.style.display = 'none'
    document.body.appendChild(link)
    link.click()
    window.setTimeout(() => {
      window.URL.revokeObjectURL(url)
      link.remove()
    }, 1000)
    ElMessage.success('Word 文档已开始下载')
  } catch (error) {
    console.error(error)
    ElMessage.error(await extractErrorMessage(error))
  } finally {
    exporting.value = false
  }
}

function buildExportPayload() {
  return {
    ...JSON.parse(JSON.stringify(form)),
    items: rows.value.map(item => ({ ...item }))
  }
}

function compareField(label, expected, actual, options = {}) {
  const actualText = String(actual ?? '').trim()
  const pass = actualText.length > 0
  return {
    label,
    expected: String(expected ?? '需填写'),
    actual: actualText || '未填写',
    status: pass ? 'pass' : (options.optional ? 'ignored' : 'fail'),
    statusText: pass ? '已填写' : (options.optional ? '可选' : '未填写'),
    note: pass ? (options.passNote || '已填写') : (options.optional ? (options.note || '可后续填写') : (options.failNote || '请填写此项'))
  }
}

function buildItemSummary(row) {
  const parts = []
  if (row?.name) parts.push(`名称：${row.name}`)
  if (row?.spec) parts.push(`规格：${row.spec}`)
  if (row?.quantity) parts.push(`数量：${row.quantity}`)
  if (row?.unitPrice) parts.push(`单价：${row.unitPrice}`)
  if (row?.totalPrice) parts.push(`合计：${row.totalPrice}`)
  return parts.length ? parts.join('｜') : '—'
}

const textChecks = computed(() => ([
  compareField('公司英文标题', defaultData.companyEn, form.companyEn, { required: true }),
  compareField('公司中文标题', defaultData.companyCn, form.companyCn, { required: true }),
  compareField('报价单中文标题', defaultData.quoteCn, form.quoteCn, { required: true }),
  compareField('报价单英文标题', defaultData.quoteEn, form.quoteEn, { required: true }),
  compareField('公司简介-1', defaultData.introPage1[0], form.introPage1[0], { required: true }),
  compareField('公司简介-2', defaultData.introPage1[1], form.introPage1[1], { required: true }),
  ...defaultData.introPage2.map((text, index) => compareField(`公司简介第2页-${index + 1}`, text, form.introPage2[index], { required: true })),
  ...defaultData.techRequirements.map((text, index) => compareField(`技术要求-${index + 1}`, text, form.techRequirements[index], { required: true })),
  compareField('冷轧型材说明', defaultData.techColdSpec, form.techColdSpec, { required: true }),
  compareField('焊接工艺', defaultData.techWeldSpec, form.techWeldSpec, { required: true }),
  compareField('表面处理', defaultData.surfaceTreatment || '', form.surfaceTreatment || '', { note: '可后续继续编辑' }),
  compareField('工艺流程', defaultData.processFlow || '', form.processFlow || '', { note: '可后续继续编辑' }),
  compareField('货架表面颜色', defaultData.surfaceColor, form.surfaceColor, { optional: true, note: '原文留空，可后续填写' }),
  compareField('备注', defaultData.remark, form.remark, { required: true }),
  compareField('售后服务-1', defaultData.afterSales[0], form.afterSales[0], { required: true }),
  compareField('售后服务-2', defaultData.afterSales[1], form.afterSales[1], { required: true }),
  compareField('售后服务-3', defaultData.afterSales[2], form.afterSales[2], { required: true }),
  compareField('售后服务-4', defaultData.afterSalesMore[0], form.afterSalesMore[0], { required: true }),
  compareField('售后服务-5', defaultData.afterSalesMore[1], form.afterSalesMore[1], { required: true })
]))

const baseChecks = computed(() => ([
  compareField('采购方', defaultData.leftBuyer, form.leftBuyer, { required: true }),
  compareField('供货方', defaultData.rightSupplier, form.rightSupplier, { required: true }),
  compareField('左侧部门', defaultData.leftDepartment, form.leftDepartment),
  compareField('右侧部门', defaultData.rightDepartment, form.rightDepartment, { required: true }),
  compareField('左侧联系人', defaultData.leftContact, form.leftContact),
  compareField('右侧联系人', defaultData.rightContact, form.rightContact, { required: true }),
  compareField('左侧传真', defaultData.leftFax, form.leftFax),
  compareField('右侧传真', defaultData.rightFax, form.rightFax),
  compareField('左侧电话', defaultData.leftTel, form.leftTel),
  compareField('右侧电话', defaultData.rightTel, form.rightTel, { required: true }),
  compareField('左侧日期', defaultData.leftDate, form.leftDate, { required: true }),
  compareField('右侧日期', defaultData.rightDate, form.rightDate, { required: true })
]))

function runValidation() {
  const docs = textChecks.value
  const header = baseChecks.value
  const itemChecks = []

  rows.value.forEach((row, index) => {
    const allBlank = !String(row?.name || '').trim() && !String(row?.spec || '').trim() && !String(row?.quantity || '').trim() && !String(row?.unitPrice || '').trim() && !String(row?.totalPrice || '').trim()
    if (allBlank) {
      itemChecks.push({
        index,
        label: `第 ${index + 1} 行`,
        expectedSummary: '可填写明细',
        actualSummary: '未填写',
        status: 'ignored',
        statusText: '空行忽略',
        note: '当前为空行，暂不参与校验'
      })
      return
    }

    const nameFilled = compareField('名称', '需填写', row.name, { required: true })
    const specFilled = compareField('规格', '需填写', row.spec, { optional: false })
    const quantityFilled = compareField('数量', '需填写', row.quantity, { required: true })
    const unitPriceFilled = compareField('单价', '需填写', row.unitPrice, { required: true })
    const totalFilled = compareField('合计', '自动计算', row.totalPrice, { required: true })

    const fieldResults = [nameFilled, specFilled, quantityFilled, unitPriceFilled, totalFilled]
    const failed = fieldResults.some(item => item.status === 'fail')

    itemChecks.push({
      index,
      label: String(row.name || `第 ${index + 1} 行`),
      expectedSummary: '填写即可通过',
      actualSummary: buildItemSummary(row),
      status: failed ? 'fail' : 'pass',
      statusText: failed ? '未填写完整' : '已填写',
      note: failed ? '名称、规格、数量、单价、合计都需要填写' : '当前行已填写完成',
      fieldResults
    })
  })

  const allChecks = [...header, ...docs, ...itemChecks]
  const countedChecks = allChecks.filter(item => item.status !== 'ignored')
  const total = countedChecks.length
  const passed = countedChecks.filter(item => item.status === 'pass').length
  const failed = countedChecks.filter(item => item.status === 'fail').length
  const rate = total ? Math.round((passed / total) * 1000) / 10 : 100

  const issues = []
  header.forEach((item) => {
    if (item.status === 'fail') issues.push(`基础信息「${item.label}」未填写：请补充`)
  })
  docs.forEach((item) => {
    if (item.status === 'fail') issues.push(`文案「${item.label}」未填写：请补充`)
  })
  itemChecks.forEach((item, index) => {
    if (item.status === 'fail') issues.push(`明细第 ${index + 1} 行未填写完整：${item.actualSummary}`)
  })

  report.value = {
    pass: failed === 0,
    summary: { total, passed, failed, rate },
    baseChecks: header,
    textChecks: docs,
    itemChecks,
    issues: issues.length ? issues : ['全部已通过校验']
  }

  ElMessage[failed === 0 ? 'success' : 'warning'](failed === 0 ? '校验完成，当前内容已填写完整。' : '校验完成，存在未填写内容。')
}
</script>

<style scoped>
.quotation-verify-page {
  padding: 16px 12px 28px;
}

.editor-toolbar {
  position: sticky;
  top: 12px;
  z-index: 10;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 16px;
  padding: 12px 14px;
  border: 1px solid #dbe3ef;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(10px);
  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.06);
}

.toolbar-left {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.toolbar-hint {
  color: #64748b;
  font-size: 13px;
}

.toolbar-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.doc-stack {
  display: grid;
  gap: 18px;
  margin-bottom: 18px;
}

.doc-page {
  width: min(100%, 1120px);
  margin: 0 auto;
  padding: 42px 44px 54px;
  background: #fff;
  border: 1px solid #dbe3ef;
  border-radius: 18px;
  box-shadow: 0 16px 40px rgba(15, 23, 42, 0.08);
}

.doc-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 20px;
}

.compact-header {
  margin-bottom: 16px;
}

.doc-logo {
  width: 108px;
  height: auto;
  object-fit: contain;
  flex: 0 0 auto;
}

.doc-header-title {
  flex: 1;
  text-align: center;
}

.doc-title-edit {
  width: 100%;
  border: none;
  background: transparent;
  outline: none;
  resize: none;
  text-align: center;
  font: inherit;
  color: inherit;
  padding: 0;
  overflow: hidden;
}

.title-en-edit {
  font-size: 28px;
  font-weight: 800;
  line-height: 1.1;
}

.title-cn-edit {
  font-size: 32px;
  font-weight: 800;
  margin-top: 2px;
}

.quote-cn-edit {
  font-size: 34px;
  font-weight: 800;
  margin-top: 28px;
}

.quote-en-edit {
  font-size: 24px;
  font-weight: 700;
  margin-top: 10px;
}

.compact-edit {
  font-size: 26px;
}

.mini-table {
  border: 1px solid #94a3b8;
  margin-top: 22px;
  margin-bottom: 20px;
}

.mini-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  border-top: 1px solid #94a3b8;
}

.mini-row:first-child {
  border-top: none;
}

.mini-cell {
  min-height: 58px;
  padding: 10px 12px;
  border-left: 1px solid #94a3b8;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 6px;
}

.mini-cell:first-child {
  border-left: none;
}

.mini-cell span {
  font-size: 13px;
  color: #1f2937;
}

.inline-input {
  min-height: 28px;
  font-size: 15px;
  color: #111827;
}

.word-input,
.word-textarea {
  width: 100%;
  border: none;
  outline: none;
  background: transparent;
  color: inherit;
  font: inherit;
  padding: 0;
  resize: none;
}

.word-input::placeholder,
.word-textarea::placeholder {
  color: #9ca3af;
}

.section-block {
  margin-top: 16px;
}

.section-block h2 {
  font-size: 20px;
  font-weight: 800;
  margin: 0 0 12px;
}

.body-textarea {
  width: 100%;
  font-size: 14px;
  line-height: 1.9;
  margin: 0 0 8px;
  color: #111827;
  text-indent: 2em;
}

.inline-line {
  text-indent: 0;
}

.numbered-list {
  display: grid;
  gap: 10px;
  margin-bottom: 8px;
}

.list-textarea {
  width: 100%;
  font-size: 14px;
  line-height: 1.8;
  margin: 0;
  text-indent: 2em;
}

.spec-table,
.quote-table,
.cases-table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
  margin: 8px 0 12px;
}

.spec-table th,
.spec-table td,
.quote-table th,
.quote-table td,
.cases-table th,
.cases-table td {
  border: 1px solid #64748b;
  padding: 8px 10px;
  text-align: center;
  vertical-align: middle;
}

.spec-table th,
.quote-table th,
.cases-table th {
  background: #f8fafc;
  font-weight: 700;
}

.narrow th,
.narrow td {
  font-size: 13px;
}

.wide-top th,
.wide-top td {
  font-size: 13px;
}

.table-input {
  min-height: 28px;
  font-size: 13px;
  text-align: center;
}

.table-input.center {
  text-align: center;
}

.top-gap-small {
  margin-top: 10px;
}

.surface-color-input {
  min-height: 30px;
  width: 100%;
  font-size: 15px;
}

.quote-line-editor {
  display: grid;
  gap: 8px;
  margin-bottom: 10px;
}

.line-title-input {
  min-height: 30px;
  font-size: 15px;
}

.line-desc-input {
  min-height: 44px;
  font-size: 14px;
  line-height: 1.7;
}

.merged-row {
  text-align: left !important;
  padding: 10px 12px !important;
}

.merged-prefix {
  display: inline-block;
  margin-right: 4px;
  font-weight: 700;
}

.merged-textarea {
  width: calc(100% - 110px);
  min-height: 46px;
  font-size: 14px;
  line-height: 1.8;
  vertical-align: top;
}

.table-cell-with-action {
  display: flex;
  align-items: center;
  gap: 8px;
}

.delete-inline-btn {
  flex: 0 0 auto;
}

.grand-total-cell {
  font-weight: 700;
}

.remark-textarea {
  width: 100%;
  min-height: 44px;
  font-size: 14px;
  line-height: 1.7;
}

.doc-footer {
  margin-top: 18px;
  display: grid;
  gap: 3px;
  font-size: 12px;
  color: #334155;
}

.panel-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.result-card {
  width: min(100%, 1120px);
  margin: 0 auto;
}

.result-overview {
  margin-bottom: 12px;
}

.stat-box {
  border: 1px solid #dbe3ef;
  border-radius: 12px;
  padding: 14px 16px;
  background: #fff;
}

.stat-box span {
  display: block;
  color: #64748b;
  font-size: 13px;
  margin-bottom: 6px;
}

.stat-box strong {
  font-size: 22px;
  color: #0f172a;
}

.issue-alert {
  margin-bottom: 14px;
}

.issue-list {
  margin: 8px 0 0;
  padding-left: 18px;
}

.report-table {
  margin-bottom: 16px;
}
</style>
