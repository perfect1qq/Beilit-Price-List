const TRANSFER_KEY = 'quotation-history-transfer'

export const saveQuotationHistoryTransfer = (payload) => {
  sessionStorage.setItem(TRANSFER_KEY, JSON.stringify(payload))
}

export const consumeQuotationHistoryTransfer = () => {
  const raw = sessionStorage.getItem(TRANSFER_KEY)
  if (!raw) return null

  sessionStorage.removeItem(TRANSFER_KEY)
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}

export const clearQuotationHistoryTransfer = () => {
  sessionStorage.removeItem(TRANSFER_KEY)
}
